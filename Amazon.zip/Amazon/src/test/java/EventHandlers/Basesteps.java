package EventHandlers;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import ObjectRepo.Login_OR;
import ObjectRepo.SupplyLocatorInfo;

public class Basesteps extends GetWebElements implements initEvent{
WebDriver driver;
GetWebElements gw = new GetWebElements();
	
	

	public Basesteps(WebDriver driver) {
	this.driver = driver;
}



	public boolean isElementPresent(SupplyLocatorInfo sli) throws Exception {
		WebElement element = gw.getWebElement(driver, sli);
		return element.isDisplayed();
	}



	public void clickElement(SupplyLocatorInfo sli) {
		WebElement element = gw.getWebElement(driver, sli);
		element.click();	
	}


	public void takeScreenshot(String path) throws IOException {
		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(screenshotFile, new File("C:\\Users\\a814783\\eclipse-workspace\\Amazon\\Screenshot\\"+path+".png"));	
	}
	
	public void selectByVisibleText(SupplyLocatorInfo sli,String text)
	{
		WebElement element = gw.getWebElement(driver, sli);
		Select visText = new Select(element) ;
		visText.selectByVisibleText(text);
		
	}
	
	public WebElement getWebElement(SupplyLocatorInfo sli) {
		WebElement element = gw.getWebElement(driver, sli);
		return element;
		
	}



	public List<WebElement> getWebElementList(SupplyLocatorInfo sli) {
		
		List<WebElement> element = (List<WebElement>) gw.getWebElementList(driver, sli);
		return element;
	}



	public String getWebElementText(Login_OR heading) {
		WebElement element = gw.getWebElement(driver, heading);	
		return element.getText();
	}
	
	
	
	
	
}
