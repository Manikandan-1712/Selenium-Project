package EventHandlers;

import org.openqa.selenium.WebElement;

import ObjectRepo.SupplyLocatorInfo;

public interface initEvent {

	 boolean isElementPresent(SupplyLocatorInfo sli) throws Exception;
	 
	 void clickElement (SupplyLocatorInfo sli) throws Exception;
	 
}
	