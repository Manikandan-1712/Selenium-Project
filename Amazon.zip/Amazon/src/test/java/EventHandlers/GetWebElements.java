package EventHandlers;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import ObjectRepo.SupplyLocatorInfo;

public class GetWebElements {
	WebDriver driver ;
	
	public WebElement getWebElement (WebDriver driver, SupplyLocatorInfo sli) throws WebDriverException {		
		return getWebElement (driver, sli.getLocatorBy());
}
	public List<WebElement> getWebElementList (WebDriver driver, SupplyLocatorInfo sli) throws WebDriverException {		
		return getWebElementList (driver, sli.getLocatorBy());
}
public WebElement getWebElement (WebDriver driver, By by) throws WebDriverException {
		
		WebElement webElement = null;
		try{
						
			webElement = driver.findElement(by);
		} 
		 catch (NullPointerException e){
			throw new NullPointerException("Null value in finding the element: " +e.getMessage());
		} 
		return webElement;	
	}

public List<WebElement> getWebElementList (WebDriver driver, By by) throws WebDriverException {
	
	List<WebElement> webElement = null;
	try{
					
		webElement = driver.findElements(by);
	} 
	 catch (NullPointerException e){
		throw new NullPointerException("Null value in finding the element: " +e.getMessage());
	} 
	return webElement;	
}

	
}
