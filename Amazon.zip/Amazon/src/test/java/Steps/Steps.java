package Steps;

import static org.junit.Assert.assertEquals;
import static org.junit.Assume.assumeTrue;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.gherkin.model.Feature;
import com.aventstack.extentreports.model.Report;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.ExtentSparkReporterConfig.ExtentSparkReporterConfigBuilder;

import EventHandlers.Basesteps;
import EventHandlers.GetWebElements;
import ObjectRepo.Login_OR;

import org.apache.commons.io.FileUtils;



import io.cucumber.java.en.*;


public class Steps {
	
	WebDriver driver = new EdgeDriver();
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	private String parent;
	private String childWindow;
	

	public Basesteps bs = new Basesteps(driver);
	
	@Given("open Amazon wesite")
	public void open_amazon_wesite() throws Exception {
		System.setProperty("webdriver.edge.driver", "./Drivers/msedgedriver.exe");
	    driver.manage().window().maximize();
	    driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
	    driver.get("https://www.amazon.in/");	
	wait.until(ExpectedConditions.visibilityOf( bs.getWebElement(Login_OR.LOGOLINK)));
	boolean logo = bs.isElementPresent(Login_OR.LOGO) ;
	if(logo) {
		System.out.println("Successfully navigated to Amazon.in");	
		bs.takeScreenshot("homeScreen");
		
		
	}
	else {
		System.out.println("Navigated to Amazon.in is Failed");	
		
		
	}
	}

	@Given("Select mobiles")
	public void login_as_user() throws InterruptedException {
	
	Thread.sleep(3000);
	bs.clickElement(Login_OR.MOBILES_COLUMN);
		Thread.sleep(3000);

	driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
	
	bs.clickElement(Login_OR.SMARTPHONES);
	 driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
	System.out.println("Select Brand");
		 WebElement Branch =  bs.getWebElement(Login_OR.BRANCH);
		 Branch.click();
		 int size = driver.getWindowHandles().size();
			System.out.println("Total number of windows "+size);
		
		System.out.println("Select 8 GM Ram");
		 WebElement ram = bs.getWebElement(Login_OR.RAM);
		 ram.click();
		 parent = driver.getWindowHandle();
		 bs.clickElement(Login_OR.IMGDATA);
		 driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		 Thread.sleep(5000);
		 
	}

	@When("switch to next window")
	public void logout_from_amazon() throws InterruptedException, IOException {		
		int size = driver.getWindowHandles().size();
		System.out.println("Total number of windows "+size);
		Set<String> s= driver.getWindowHandles();
		System.out.println("number of frames: "+s);
		Iterator<String>iter = s.iterator();
		Thread.sleep(2000);
		if(iter.hasNext()) {
			String parenWindow = iter.next();
			 childWindow = iter.next();
			
			System.out.println("chiled window name : "+childWindow);
			if(parent!= childWindow)
			{
				
				driver.switchTo().window(childWindow);
				
				System.out.println("Title of window "+driver.switchTo().window(childWindow).getTitle());
				WebElement cart = bs.getWebElement(Login_OR.SUBMITADDTPOCART);
				if(cart.isDisplayed()) {
					System.out.println("Cart Button is Displaying");
					bs.takeScreenshot("cartbuttton");
				}
				else {
					System.out.println("Cart Button is Not Displaying");
				}
			}
		}	
		else {
			System.out.println("No New Window is opened");
		}
	
	}
	
	
	
	@When("Add part to cart and validate cart screen")
	public void addPartToCart() throws InterruptedException, IOException 	
	{
		
		WebElement cart = bs.getWebElement(Login_OR.SHOPPINGCART);
		if(cart.isDisplayed()){
			cart.click();
			Thread.sleep(3000);
			System.out.println("Numbtre of Windows "+driver.getWindowHandles().size());
			
			driver.navigate().refresh();	
			WebElement cartScreen = bs.getWebElement(Login_OR.Cart);
			cartScreen.click();
			String heading = bs.getWebElementText(Login_OR.HEADING);
			if(heading.contains("Cart")) {
				System.out.println("Cart page validated Successfully");				
			}else {
				System.out.println("Cart page not validated Successfully");
			}
			bs.takeScreenshot("cart");
		}
		
	}

	
	
	@Given("select {string} in dropdown")
	public void select_in_dropdown(String string) {
	    WebElement path = bs.getWebElement(Login_OR.DROPDOWN);
	   bs.selectByVisibleText(Login_OR.DROPDOWN, string);
	}
	
	@Then("Print all Dropdown option in console")
	public void printAll() {
		List<WebElement> path = bs.getWebElementList(Login_OR.DROPDOWNList);
	    for(WebElement a : path) {
	    	System.out.println("Options ::  "+a.getText());
	    	
	    }
	   
	}
	
}
