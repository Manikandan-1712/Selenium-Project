package ObjectRepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public enum Login_OR implements SupplyLocatorInfo{
	
	LOGO(By.xpath("//a[@class='nav-logo-link nav-progressive-attribute']"),"Logo of WebPage"),
	MOBILES_COLUMN(By.xpath("//a[contains(text(),'Mobiles')]"),"Mobiles Column"),
	SMARTPHONES(By.xpath("//span[contains(text(),'Smartphones & Basic Mobiles')]"),"Smart Phones"),
	DROPDOWN(By.xpath("//select[@id='searchDropdownBox']"),"Select dropdwon"),
	DROPDOWNList(By.xpath("//select[@id='searchDropdownBox']/option"),"Select dropdwon"),
	HEADING(By.xpath("//div[@class='a-row sc-cart-header sc-compact-bottom']/div/h1"),"Heading"),
	Cart(By.xpath("//a[@id='nav-cart']"),"cart"),
	SHOPPINGCART(By.xpath("//input[@title='Add to Shopping Cart']"),"Shopping cart"),
	SUBMITADDTPOCART(By.xpath("//span[@id='submit.add-to-cart-announce']"),"Submit add to cart"),
	RAM(By.xpath("//span[contains(text(),'8 to 9.9 GB')]"),"RAM SELECTION"),
	BRANCH(By.xpath("//ul[@class='a-unordered-list a-nostyle a-vertical a-spacing-medium']//span[contains(text(),'OnePlus')]"),"BRANCH"),
	LOGOLINK(By.xpath("//a[@class='nav-logo-link nav-progressive-attribute']"),"Logo Link"),
	IMGDATA(By.xpath("//img[@data-image-index='1']"),"IMAGE "),
	
	
	
	
	;
	By element;
	String identified;
	WebElement webElem;
	Login_OR(By element, String identified) {
		this.element = element;
		this.identified = identified;
	}

	public WebElement getWebElement() {
		
		return this.webElem;
	}

	public By getLocatorBy() {
		// TODO Auto-generated method stub
		return this.element;
	}

	public String getLabel() {
		// TODO Auto-generated method stub
		return this.identified;
	}

}
